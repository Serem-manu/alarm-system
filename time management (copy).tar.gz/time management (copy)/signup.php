body {
    background-color:rgb(64, 196, 230); 
      font-family: 'Arial', sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
  }
  .signup-container{
      text-align: center;
      padding: 20px;
    box-shadow: 1px 1px 17px 4px grey;
      border-radius: 8px;
      background-color:#00FF00;
      display: flex;
    flex-direction:column;
    background-color:rgb(80, 107, 228);
  border: 1px solid rgb(0, 0, 0); 
  }
  .button {
    background-color: #233f9b; 
    color: rgb(255, 255, 255);
    padding: 10px;
    text-align: center;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 5px;
    border: none ;
  }
  
